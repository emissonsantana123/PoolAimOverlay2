package com.poolaim.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private AimView aimView;
    private View panel;
    private WindowManager.LayoutParams aimParams;
    private WindowManager.LayoutParams panelParams;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        aimParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        aimParams.gravity = Gravity.TOP | Gravity.START;
        aimView = new AimView(this);
        wm.addView(aimView, aimParams);
        createPanel(type);
    }

    private void createPanel(int type) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14, 12, 14, 12);
        box.setBackgroundColor(Color.argb(235, 16, 25, 35));

        TextView title = new TextView(this);
        title.setText("POOL AIM  •  arraste o título");
        title.setTextColor(Color.rgb(53, 255, 174));
        title.setTextSize(14);
        title.setPadding(0, 0, 0, 7);
        box.addView(title);

        title.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = panelParams.x; startY = panelParams.y; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    panelParams.x = startX + (int)(e.getRawX() - downX);
                    panelParams.y = startY + (int)(e.getRawY() - downY);
                    wm.updateViewLayout(panel, panelParams); return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });

        TextView angleLabel = new TextView(this);
        angleLabel.setTextColor(Color.WHITE);
        angleLabel.setText("Ângulo: 0°");
        box.addView(angleLabel);
        SeekBar angle = new SeekBar(this);
        angle.setMax(359); angle.setProgress(0);
        box.addView(angle);
        angle.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                aimView.setAngle(p); angleLabel.setText("Ângulo: " + p + "°");
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        TextView xLabel = new TextView(this);
        xLabel.setTextColor(Color.WHITE); xLabel.setText("Posição horizontal");
        box.addView(xLabel);
        SeekBar posX = new SeekBar(this); posX.setMax(1000); posX.setProgress(350);
        box.addView(posX);
        posX.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                aimView.setOriginX(p / 1000f);
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        TextView yLabel = new TextView(this);
        yLabel.setTextColor(Color.WHITE); yLabel.setText("Posição vertical");
        box.addView(yLabel);
        SeekBar posY = new SeekBar(this); posY.setMax(1000); posY.setProgress(550);
        box.addView(posY);
        posY.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                aimView.setOriginY(p / 1000f);
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        TextView lengthLabel = new TextView(this);
        lengthLabel.setTextColor(Color.WHITE); lengthLabel.setText("Comprimento: 300");
        box.addView(lengthLabel);
        SeekBar length = new SeekBar(this); length.setMax(650); length.setProgress(250);
        box.addView(length);
        length.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                int value = Math.max(50, p);
                aimView.setLength(value); lengthLabel.setText("Comprimento: " + value);
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        LinearLayout buttons = new LinearLayout(this);
        Button toggle = new Button(this); toggle.setText("Ocultar mira");
        Button close = new Button(this); close.setText("Fechar");
        buttons.addView(toggle, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(close, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(buttons);
        toggle.setOnClickListener(v -> {
            boolean visible = aimView.toggleVisible();
            toggle.setText(visible ? "Ocultar mira" : "Mostrar mira");
        });
        close.setOnClickListener(v -> stopSelf());

        panel = box;
        panelParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = 16; panelParams.y = 70;
        wm.addView(panel, panelParams);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        if (wm != null) {
            try { if (aimView != null) wm.removeView(aimView); } catch (Exception ignored) {}
            try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
