package com.poolaim.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_PERMISSION_REQUEST = 701;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showScreen();
    }

    @Override protected void onResume() {
        super.onResume();
    }

    private void showScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setBackgroundColor(Color.rgb(16, 25, 35));

        TextView title = new TextView(this);
        title.setText("🎱 Pool Aim Overlay");
        title.setTextColor(Color.rgb(53, 255, 174));
        title.setTextSize(25);
        title.setPadding(0, 0, 0, 18);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("Mira visual flutuante para treino manual. Ajuste a linha por toque e use o painel sobre o jogo. A trajetória é apenas uma referência, não uma previsão física exata.");
        desc.setTextColor(Color.WHITE);
        desc.setTextSize(16);
        desc.setPadding(0, 0, 0, 24);
        root.addView(desc);

        Button permission = new Button(this);
        permission.setText("1. Permitir sobreposição");
        root.addView(permission);
        permission.setOnClickListener(v -> requestOverlayPermission());

        Button start = new Button(this);
        start.setText("2. Iniciar mira flutuante");
        root.addView(start);
        start.setOnClickListener(v -> startOverlay());

        Button stop = new Button(this);
        stop.setText("Fechar mira flutuante");
        root.addView(stop);
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));

        TextView hint = new TextView(this);
        hint.setText("Como usar: conceda a permissão, inicie a mira e abra o 8 Ball Pool. Arraste o círculo verde para mover a origem; arraste o marcador vermelho para ajustar direção e comprimento. Use o painel para ocultar ou fechar.");
        hint.setTextColor(Color.LTGRAY);
        hint.setTextSize(13);
        hint.setPadding(0, 24, 0, 0);
        root.addView(hint);
        setContentView(root);
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
        }
    }

    private void startOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            requestOverlayPermission();
            return;
        }
        Intent intent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
        finish();
    }
}
