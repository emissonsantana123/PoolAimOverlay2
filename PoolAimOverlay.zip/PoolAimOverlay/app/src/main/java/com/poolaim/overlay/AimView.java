package com.poolaim.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class AimView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float x = 300, y = 600, angle = 0, length = 300;
    private boolean visible = true, dragging = false, movingOrigin = false;

    public AimView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setBackgroundColor(Color.TRANSPARENT);
    }

    public void setOriginX(float fraction) { x = Math.max(10, getWidth() * fraction); invalidate(); }
    public void setOriginY(float fraction) { y = Math.max(10, getHeight() * fraction); invalidate(); }
    public void setAngle(float degrees) { angle = (float)Math.toRadians(degrees); invalidate(); }
    public void setLength(float value) { length = value; invalidate(); }
    public boolean toggleVisible() { visible = !visible; invalidate(); return visible; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!visible) return;
        float ex = x + (float)Math.cos(angle) * length;
        float ey = y + (float)Math.sin(angle) * length;

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3);
        paint.setColor(Color.rgb(53,255,174));
        paint.setPathEffect(new android.graphics.DashPathEffect(new float[]{14,10},0));
        canvas.drawLine(x,y,ex,ey,paint);
        paint.setPathEffect(null);

        paint.setColor(Color.argb(210,255,255,255));
        paint.setStrokeWidth(2);
        canvas.drawLine(ex,ey,ex+(float)Math.cos(angle)*100,ey+(float)Math.sin(angle)*100,paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(53,255,174));
        canvas.drawCircle(x,y,10,paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(x,y,10,paint);

        paint.setColor(Color.rgb(255,64,92));
        canvas.drawCircle(ex,ey,14,paint);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(ex,ey,4,paint);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawLine(ex-20,ey,ex+20,ey,paint);
        canvas.drawLine(ex,ey-20,ex,ey+20,paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float tx=e.getX(), ty=e.getY();
        switch(e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                float ex=x+(float)Math.cos(angle)*length;
                float ey=y+(float)Math.sin(angle)*length;
                dragging=true;
                movingOrigin=Math.hypot(tx-ex,ty-ey)>38;
                if (movingOrigin) { x=tx; y=ty; }
                else updateAim(tx,ty);
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                if (!dragging) return false;
                if (movingOrigin) { x=tx; y=ty; }
                else updateAim(tx,ty);
                invalidate(); return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging=false; performClick(); invalidate(); return true;
        }
        return true;
    }

    private void updateAim(float tx,float ty) {
        float dx=tx-x, dy=ty-y;
        if (Math.hypot(dx,dy)>5) {
            angle=(float)Math.atan2(dy,dx);
            length=Math.max(50,Math.min(700,(float)Math.hypot(dx,dy)));
        }
    }

    @Override public boolean performClick() { super.performClick(); return true; }
}
